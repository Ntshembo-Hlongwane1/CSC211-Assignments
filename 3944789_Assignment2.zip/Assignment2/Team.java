public class Team {

  String teamName;
  int teamNumber;
  long regYear;
  int firstScore;
  int secondScore;
  double finalScore;

  Team(String teamName, int teamNumber, long regYear, int firstScore, int secondScore) {
    this.teamName = teamName;
    this.teamNumber = teamNumber;
    this.regYear = regYear;
    this.firstScore = firstScore;
    this.secondScore = secondScore;
  }

}
